#include <stdio.h>

#include "subdir/test.h"

int main(void) {
	printf("Hello world\n");
	test();
}